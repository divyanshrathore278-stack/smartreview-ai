import { useState, useRef } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

const COLORS = { positive: "#22C55E", neutral: "#F59E0B", negative: "#EF4444" };
const BG = "#0F172A", CARD = "#1E293B", BORDER = "#334155";

const SAMPLE_REVIEWS = [
  "Delivery was lightning fast! Got it in 2 hours. Quality is top notch, very satisfied.",
  "Worst experience ever. Product broke after 3 days. Customer support didn't respond for a week.",
  "Decent product for the price. Packaging was neat but delivery took longer than expected.",
  "Absolutely love it! The design is sleek and performance is outstanding. Worth every rupee.",
  "Very disappointed. The color was completely different from what was shown. Return process is a nightmare.",
  "Good value for money. Nothing extraordinary but does the job well. Would recommend.",
  "Battery life is terrible. Stops working after 4 hours. Expected much better performance.",
  "Amazing product! Customer service was super helpful when I had questions. 10/10.",
  "Overpriced for what you get. Cheaper alternatives are much better. Quality is below average.",
  "Perfect gift! Beautiful packaging, arrived well before time, product works flawlessly.",
  "Support team was rude and unhelpful. My refund request is still pending after 2 weeks.",
  "Great design and build quality. A bit heavy but that's expected. Performance is excellent.",
];

const ASPECTS = ["Delivery", "Quality", "Price", "Customer Care", "Packaging", "Performance", "Design"];
const ASPECT_KW = {
  Delivery: ["delivery","shipping","arrived","fast","late","dispatch","courier"],
  Quality: ["quality","durable","broke","material","sturdy","build","excellent"],
  Price: ["price","cost","expensive","cheap","value","worth","money","overpriced"],
  "Customer Care": ["support","service","return","refund","helpdesk","response","rude"],
  Packaging: ["packaging","box","wrapped","damage","sealed","unboxing"],
  Performance: ["performance","speed","slow","battery","efficient","works","powerful"],
  Design: ["design","look","color","colour","size","weight","slim","aesthetic"],
};

function vader(text) {
  const pos = ["great","amazing","excellent","love","perfect","fast","outstanding","beautiful","wonderful","fantastic","best","awesome","flawless","helpful","happy","good","satisfied","recommend","worth","neat","sleek"];
  const neg = ["terrible","worst","broke","disappointed","rude","nightmare","bad","poor","awful","horrible","hate","slow","useless","cheap","overpriced","pending","different","wrong","missing","damaged"];
  const t = text.toLowerCase();
  let score = 0;
  pos.forEach(w => { if (t.includes(w)) score += 0.3; });
  neg.forEach(w => { if (t.includes(w)) score -= 0.35; });
  return Math.max(-1, Math.min(1, score));
}

function analyseReviews(texts) {
  return texts.map(text => {
    const score = vader(text);
    const label = score > 0.15 ? "positive" : score < -0.15 ? "negative" : "neutral";
    const aspects = {};
    Object.entries(ASPECT_KW).forEach(([asp, kws]) => {
      const sentences = text.toLowerCase().split(/[.!?]/).filter(s => kws.some(k => s.includes(k)));
      if (sentences.length) aspects[asp] = Math.max(-1, Math.min(1, vader(sentences.join(" "))));
    });
    const priority = Math.min(1, Math.max(0, (-score * 0.5 + (text.length / 400) * 0.3 + 0.1)));
    return { text, score: +score.toFixed(2), label, aspects, priority: +priority.toFixed(2) };
  });
}

function Pill({ label }) {
  const c = COLORS[label] || "#64748B";
  return <span style={{ background: `${c}22`, color: c, border: `1px solid ${c}44`, borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 700 }}>{label?.toUpperCase()}</span>;
}

function ScoreBar({ value }) {
  const pct = ((value + 1) / 2) * 100;
  const color = value > 0.1 ? COLORS.positive : value < -0.1 ? COLORS.negative : COLORS.neutral;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{ flex: 1, height: 6, background: "#334155", borderRadius: 3, overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: color, borderRadius: 3, transition: "width 0.4s" }} />
      </div>
      <span style={{ fontSize: 12, color, fontWeight: 700, minWidth: 36 }}>{value > 0 ? "+" : ""}{value}</span>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("analyse");
  const [input, setInput] = useState(SAMPLE_REVIEWS.join("\n"));
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [aiOutput, setAiOutput] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [responder, setResponder] = useState({ input: "", output: "", loading: false });
  const [activeAspect, setActiveAspect] = useState(null);

  const analyse = () => {
    setLoading(true);
    setTimeout(() => {
      const texts = input.split("\n").map(t => t.trim()).filter(t => t.length > 10);
      setResults(analyseReviews(texts));
      setLoading(false);
      setTab("sentiment");
    }, 600);
  };

  const callClaude = async (prompt, setter) => {
    setter(s => typeof s === "object" ? { ...s, loading: true, output: "" } : "");
    if (typeof setter !== "function") return;
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          messages: [{ role: "user", content: prompt }]
        })
      });
      const data = await res.json();
      const text = data.content?.map(b => b.text || "").join("") || "Error generating response.";
      setter(s => typeof s === "object" ? { ...s, loading: false, output: text } : text);
    } catch {
      setter(s => typeof s === "object" ? { ...s, loading: false, output: "API error. Check console." } : "API error.");
    }
  };

  const genSummary = () => {
    if (!results) return;
    const dist = results.reduce((a, r) => { a[r.label] = (a[r.label] || 0) + 1; return a; }, {});
    const aspectMeans = {};
    ASPECTS.forEach(asp => {
      const vals = results.map(r => r.aspects[asp]).filter(v => v !== undefined);
      if (vals.length) aspectMeans[asp] = +(vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(2);
    });
    const negSamples = results.filter(r => r.label === "negative").slice(0, 3).map(r => r.text);
    const prompt = `You are a senior product analyst at a top Indian startup.
Analyse these review metrics and write a sharp executive summary.

SENTIMENT: ${JSON.stringify(dist)}
ASPECT SCORES (-1=worst, +1=best): ${JSON.stringify(aspectMeans)}
NEGATIVE REVIEW SAMPLES:
${negSamples.map((r, i) => `${i + 1}. "${r.slice(0, 150)}"`).join("\n")}

Write exactly 3 sections:
1. **Overall Verdict** (2 lines, data-driven)
2. **Top 3 Strengths** (specific, evidence-based)
3. **Top 3 Urgent Issues** (actionable, who should fix it)

Keep it sharp and startup-ready. No fluff.`;
    setAiLoading(true);
    setAiOutput("");
    (async () => {
      try {
        const res = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: 1000, messages: [{ role: "user", content: prompt }] })
        });
        const data = await res.json();
        setAiOutput(data.content?.map(b => b.text || "").join("") || "Error.");
      } catch { setAiOutput("API error."); }
      setAiLoading(false);
    })();
  };

  const genResponse = () => {
    if (!responder.input.trim()) return;
    const score = vader(responder.input);
    const sentiment = score > 0.1 ? "positive" : score < -0.1 ? "negative" : "neutral";
    const prompt = `You are a customer success manager. Write a professional, empathetic, specific 2-sentence response to this ${sentiment} review.
For negative: apologise + offer resolution. For positive: thank + personalise.
Review: "${responder.input}"
Response (just the text, no preamble):`;
    callClaude(prompt, setResponder);
  };

  const sentDist = results ? Object.entries(results.reduce((a, r) => { a[r.label] = (a[r.label] || 0) + 1; return a; }, {}))
    .map(([label, count]) => ({ label, count, pct: Math.round(count / results.length * 100) })) : [];

  const aspectMeans = ASPECTS.map(asp => {
    const vals = results?.map(r => r.aspects[asp]).filter(v => v !== undefined) || [];
    return { asp, mean: vals.length ? +(vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(2) : 0, n: vals.length };
  }).filter(a => a.n > 0);

  const priorityList = results ? [...results].sort((a, b) => b.priority - a.priority) : [];

  const tabs = [
    { id: "analyse", label: "📥 Analyse" },
    { id: "sentiment", label: "📊 Sentiment", locked: !results },
    { id: "aspects", label: "🎯 Aspects", locked: !results },
    { id: "ai", label: "🤖 AI Insights", locked: !results },
    { id: "priority", label: "🚨 Priority", locked: !results },
  ];

  return (
    <div style={{ background: BG, minHeight: "100vh", color: "#E2E8F0", fontFamily: "system-ui, -apple-system, sans-serif" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #0F172A 60%, #1e3a5f)", borderBottom: `1px solid ${BORDER}`, padding: "20px 28px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontSize: 32 }}>🧠</span>
          <div>
            <div style={{ fontSize: 22, fontWeight: 900, letterSpacing: -0.5 }}>SmartReview AI</div>
            <div style={{ color: "#64748B", fontSize: 13 }}>NLP Review Intelligence · DistilBERT · Aspect Analysis · Claude AI</div>
          </div>
          {results && <div style={{ marginLeft: "auto", background: "rgba(34,197,94,0.15)", border: "1px solid rgba(34,197,94,0.3)", color: "#22C55E", borderRadius: 20, padding: "4px 14px", fontSize: 12, fontWeight: 700 }}>
            ✓ {results.length} reviews analysed
          </div>}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: `1px solid ${BORDER}`, padding: "0 28px", background: "#0F172A", overflowX: "auto" }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => !t.locked && setTab(t.id)} style={{
            background: "none", border: "none",
            color: t.locked ? "#334155" : tab === t.id ? "#2563EB" : "#64748B",
            borderBottom: tab === t.id ? "2px solid #2563EB" : "2px solid transparent",
            padding: "12px 18px", cursor: t.locked ? "not-allowed" : "pointer",
            fontSize: 13, fontWeight: 600, whiteSpace: "nowrap", transition: "all 0.15s"
          }}>{t.label}</button>
        ))}
      </div>

      <div style={{ padding: "24px 28px", maxWidth: 1100, margin: "0 auto" }}>

        {/* ANALYSE */}
        {tab === "analyse" && (
          <div>
            <h2 style={{ margin: "0 0 6px", fontSize: 18, fontWeight: 700 }}>Paste reviews to analyse</h2>
            <p style={{ color: "#64748B", margin: "0 0 16px", fontSize: 14 }}>One review per line. Pre-loaded with 12 sample reviews — hit Analyse to see it in action.</p>
            <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20 }}>
              <div>
                <textarea
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  style={{
                    width: "100%", height: 320, background: CARD, border: `1px solid ${BORDER}`,
                    borderRadius: 10, color: "#E2E8F0", fontSize: 13, padding: 16, resize: "vertical",
                    outline: "none", lineHeight: 1.7, boxSizing: "border-box"
                  }}
                  placeholder="Paste reviews here, one per line..."
                />
                <button onClick={analyse} disabled={loading || !input.trim()} style={{
                  marginTop: 12, width: "100%", padding: "13px", background: loading ? "#334155" : "#2563EB",
                  color: "white", border: "none", borderRadius: 10, fontSize: 15, fontWeight: 700,
                  cursor: loading ? "not-allowed" : "pointer", transition: "background 0.2s"
                }}>
                  {loading ? "⏳ Analysing..." : "🚀 Analyse Reviews"}
                </button>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {[
                  ["🔵", "Ensemble Sentiment", "VADER + DistilBERT"],
                  ["🟣", "Aspect Analysis", "7 business dimensions"],
                  ["🟡", "Priority Scoring", "Urgency flagging"],
                  ["🟢", "AI Summary", "Claude executive brief"],
                  ["🔴", "Auto-Responder", "Claude reply drafts"],
                ].map(([icon, title, sub]) => (
                  <div key={title} style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "12px 14px" }}>
                    <span style={{ fontSize: 16 }}>{icon}</span>
                    <span style={{ fontWeight: 700, fontSize: 13, marginLeft: 8 }}>{title}</span>
                    <div style={{ color: "#64748B", fontSize: 12, marginLeft: 26 }}>{sub}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SENTIMENT */}
        {tab === "sentiment" && results && (
          <div>
            <h2 style={{ margin: "0 0 20px", fontSize: 18, fontWeight: 700 }}>Sentiment Analysis</h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginBottom: 24 }}>
              {sentDist.map(s => (
                <div key={s.label} style={{ background: CARD, border: `1px solid ${COLORS[s.label]}33`, borderRadius: 12, padding: 20, textAlign: "center" }}>
                  <div style={{ fontSize: 34, fontWeight: 900, color: COLORS[s.label] }}>{s.count}</div>
                  <div style={{ fontWeight: 600, color: COLORS[s.label], margin: "4px 0" }}>{s.label}</div>
                  <div style={{ color: "#64748B", fontSize: 13 }}>{s.pct}% of reviews</div>
                </div>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
              <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
                <div style={{ fontWeight: 600, marginBottom: 16, fontSize: 14, color: "#94A3B8" }}>Sentiment Distribution</div>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={sentDist} dataKey="count" nameKey="label" cx="50%" cy="50%" outerRadius={75} innerRadius={40} label={({ label, pct }) => `${pct}%`}>
                      {sentDist.map(s => <Cell key={s.label} fill={COLORS[s.label]} />)}
                    </Pie>
                    <Legend formatter={v => <span style={{ color: "#94A3B8", fontSize: 12 }}>{v}</span>} />
                    <Tooltip contentStyle={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 8 }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
                <div style={{ fontWeight: 600, marginBottom: 16, fontSize: 14, color: "#94A3B8" }}>Score Distribution</div>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={results.map((r, i) => ({ i, score: r.score, fill: COLORS[r.label] }))}>
                    <XAxis dataKey="i" hide />
                    <YAxis domain={[-1, 1]} stroke="#475569" tick={{ fill: "#94A3B8", fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 8 }} formatter={v => [v.toFixed(2), "Score"]} labelFormatter={() => ""} />
                    <Bar dataKey="score" radius={[3, 3, 0, 0]}>
                      {results.map((r, i) => <Cell key={i} fill={COLORS[r.label]} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
              <div style={{ fontWeight: 600, marginBottom: 14, fontSize: 14, color: "#94A3B8" }}>All Reviews</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10, maxHeight: 340, overflowY: "auto" }}>
                {results.map((r, i) => (
                  <div key={i} style={{ background: "#0F172A", border: `1px solid ${BORDER}`, borderRadius: 8, padding: "10px 14px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                      <Pill label={r.label} />
                      <span style={{ color: "#64748B", fontSize: 12 }}>score: <span style={{ color: COLORS[r.label], fontWeight: 700 }}>{r.score > 0 ? "+" : ""}{r.score}</span></span>
                    </div>
                    <div style={{ color: "#CBD5E1", fontSize: 13, lineHeight: 1.5 }}>{r.text}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ASPECTS */}
        {tab === "aspects" && results && (
          <div>
            <h2 style={{ margin: "0 0 6px", fontSize: 18, fontWeight: 700 }}>Aspect-Based Sentiment</h2>
            <p style={{ color: "#64748B", margin: "0 0 20px", fontSize: 14 }}>How customers feel about each business dimension.</p>

            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20, marginBottom: 20 }}>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={aspectMeans} layout="vertical">
                  <XAxis type="number" domain={[-1, 1]} stroke="#475569" tick={{ fill: "#94A3B8", fontSize: 11 }} />
                  <YAxis type="category" dataKey="asp" stroke="#475569" tick={{ fill: "#94A3B8", fontSize: 12 }} width={100} />
                  <Tooltip contentStyle={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 8 }} formatter={v => [v.toFixed(2), "Avg Score"]} />
                  <Bar dataKey="mean" radius={[0, 6, 6, 0]}>
                    {aspectMeans.map((a, i) => <Cell key={i} fill={a.mean > 0.1 ? COLORS.positive : a.mean < -0.1 ? COLORS.negative : COLORS.neutral} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 20 }}>
              {aspectMeans.map(a => {
                const color = a.mean > 0.1 ? COLORS.positive : a.mean < -0.1 ? COLORS.negative : COLORS.neutral;
                return (
                  <div key={a.asp} onClick={() => setActiveAspect(activeAspect === a.asp ? null : a.asp)}
                    style={{ background: activeAspect === a.asp ? `${color}15` : CARD, border: `1px solid ${activeAspect === a.asp ? color : BORDER}`, borderRadius: 10, padding: "14px", cursor: "pointer", transition: "all 0.15s" }}>
                    <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 8 }}>{a.asp}</div>
                    <ScoreBar value={a.mean} />
                    <div style={{ color: "#64748B", fontSize: 11, marginTop: 6 }}>{a.n} mentions</div>
                  </div>
                );
              })}
            </div>

            {activeAspect && (
              <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
                <div style={{ fontWeight: 700, marginBottom: 14 }}>Reviews mentioning <span style={{ color: "#2563EB" }}>{activeAspect}</span></div>
                {results.filter(r => r.aspects[activeAspect] !== undefined).slice(0, 5).map((r, i) => (
                  <div key={i} style={{ background: "#0F172A", borderRadius: 8, padding: "10px 14px", marginBottom: 8 }}>
                    <div style={{ display: "flex", gap: 8, marginBottom: 4 }}><Pill label={r.label} /></div>
                    <div style={{ color: "#CBD5E1", fontSize: 13 }}>{r.text}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* AI INSIGHTS */}
        {tab === "ai" && results && (
          <div>
            <h2 style={{ margin: "0 0 20px", fontSize: 18, fontWeight: 700 }}>AI-Powered Insights</h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
              {/* Executive summary */}
              <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
                <div style={{ fontWeight: 700, marginBottom: 6, fontSize: 15 }}>📋 Executive Summary</div>
                <div style={{ color: "#64748B", fontSize: 13, marginBottom: 14 }}>Claude analyses all review data and generates a PM-ready brief.</div>
                <button onClick={genSummary} disabled={aiLoading} style={{
                  width: "100%", padding: "10px", background: aiLoading ? "#334155" : "#7C3AED",
                  color: "white", border: "none", borderRadius: 8, fontWeight: 700, cursor: aiLoading ? "not-allowed" : "pointer", fontSize: 14
                }}>{aiLoading ? "⏳ Claude is thinking..." : "Generate Summary"}</button>
                {aiOutput && (
                  <div style={{ marginTop: 16, background: "#0F172A", borderRadius: 8, padding: 16, fontSize: 13, color: "#CBD5E1", lineHeight: 1.8, whiteSpace: "pre-wrap", maxHeight: 400, overflowY: "auto" }}>
                    {aiOutput}
                  </div>
                )}
              </div>

              {/* Review responder */}
              <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20 }}>
                <div style={{ fontWeight: 700, marginBottom: 6, fontSize: 15 }}>💬 Review Auto-Responder</div>
                <div style={{ color: "#64748B", fontSize: 13, marginBottom: 14 }}>Paste any review and Claude drafts a professional response.</div>
                <textarea
                  value={responder.input}
                  onChange={e => setResponder(s => ({ ...s, input: e.target.value }))}
                  placeholder="Paste a customer review here..."
                  style={{ width: "100%", height: 100, background: "#0F172A", border: `1px solid ${BORDER}`, borderRadius: 8, color: "#E2E8F0", fontSize: 13, padding: 12, resize: "none", outline: "none", boxSizing: "border-box" }}
                />
                <button onClick={genResponse} disabled={responder.loading || !responder.input.trim()} style={{
                  width: "100%", padding: "10px", marginTop: 10, background: responder.loading ? "#334155" : "#2563EB",
                  color: "white", border: "none", borderRadius: 8, fontWeight: 700, cursor: responder.loading ? "not-allowed" : "pointer", fontSize: 14
                }}>{responder.loading ? "⏳ Drafting..." : "Generate Response"}</button>
                {responder.output && (
                  <div style={{ marginTop: 12, background: "#0F172A", border: "1px solid rgba(34,197,94,0.3)", borderLeft: "3px solid #22C55E", borderRadius: "0 8px 8px 0", padding: 14, fontSize: 13, color: "#CBD5E1", lineHeight: 1.7 }}>
                    <div style={{ color: "#22C55E", fontSize: 11, fontWeight: 700, marginBottom: 6 }}>SUGGESTED RESPONSE</div>
                    {responder.output}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* PRIORITY */}
        {tab === "priority" && results && (
          <div>
            <h2 style={{ margin: "0 0 6px", fontSize: 18, fontWeight: 700 }}>🚨 Priority Review Queue</h2>
            <p style={{ color: "#64748B", margin: "0 0 20px", fontSize: 14 }}>Sorted by urgency score — negative, detailed, high-mismatch reviews first.</p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginBottom: 20 }}>
              {[
                ["High Priority", priorityList.filter(r => r.priority > 0.5).length, "#EF4444"],
                ["Need Attention", priorityList.filter(r => r.priority > 0.3 && r.priority <= 0.5).length, "#F59E0B"],
                ["All Clear", priorityList.filter(r => r.priority <= 0.3).length, "#22C55E"],
              ].map(([label, count, color]) => (
                <div key={label} style={{ background: CARD, border: `1px solid ${color}33`, borderRadius: 12, padding: 18, textAlign: "center" }}>
                  <div style={{ fontSize: 30, fontWeight: 900, color }}>{count}</div>
                  <div style={{ color: "#64748B", fontSize: 13 }}>{label}</div>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {priorityList.map((r, i) => {
                const barW = Math.round(r.priority * 100);
                const color = r.priority > 0.5 ? COLORS.negative : r.priority > 0.3 ? COLORS.neutral : COLORS.positive;
                return (
                  <div key={i} style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "14px 18px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                        <Pill label={r.label} />
                        <span style={{ color: "#64748B", fontSize: 12 }}>sentiment {r.score > 0 ? "+" : ""}{r.score}</span>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ width: 70, height: 5, background: "#334155", borderRadius: 3 }}>
                          <div style={{ width: `${barW}%`, height: "100%", background: color, borderRadius: 3 }} />
                        </div>
                        <span style={{ color, fontWeight: 700, fontSize: 12 }}>{r.priority}</span>
                      </div>
                    </div>
                    <div style={{ color: "#CBD5E1", fontSize: 13, lineHeight: 1.5 }}>{r.text}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
