# 🧠 SmartReview AI — Intelligent Product Review Intelligence Platform

[![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python)](https://python.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.28-red?logo=streamlit)](https://streamlit.io)
[![HuggingFace](https://img.shields.io/badge/HuggingFace-Transformers-yellow?logo=huggingface)](https://huggingface.co)
[![Claude API](https://img.shields.io/badge/Claude-Sonnet--4--6-purple)](https://anthropic.com)
[![License](https://img.shields.io/badge/License-MIT-green)](LICENSE)

> A **production-grade NLP pipeline** that transforms raw customer reviews into structured intelligence — using an ensemble of VADER + DistilBERT for sentiment, aspect-based analysis across 7 business dimensions, BERTopic clustering, and Claude AI for executive summaries and auto-responses.

**Built for product startups like Swiggy, CRED, Zepto, and Meesho** — where understanding customer voice at scale is a core engineering and data science challenge.

---

## 🎬 Live Demo

> Paste any product reviews → get instant sentiment scores, aspect breakdowns, topic clusters, and an AI-generated product brief in under 60 seconds.

---

## 🏗️ System Architecture

```
Raw Reviews (CSV / Paste)
        │
        ▼
┌─────────────────────────────────────────────────────────┐
│  LAYER 1: Ensemble Sentiment                            │
│  ├── VADER (lexicon-based, fast)                        │
│  └── DistilBERT (transformer, fine-tuned SST-2)         │
│       Ensemble weight: 0.35×VADER + 0.65×BERT           │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│  LAYER 2: Aspect-Based Sentiment Analysis (ABSA)        │
│  7 dimensions: Delivery · Quality · Price · Care ·      │
│                Packaging · Performance · Design          │
│  Technique: Keyword sentence extraction + VADER scoring  │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│  LAYER 3: Topic Modeling                                │
│  BERTopic (sentence-transformers/all-MiniLM-L6-v2)      │
│  → Unsupervised topic discovery, no labels needed        │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│  LAYER 4: Named Entity Recognition                      │
│  spaCy en_core_web_sm → extract brands, products, orgs  │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│  LAYER 5: LLM Intelligence (Claude Sonnet)              │
│  ├── Executive summary (verdict + strengths + issues)   │
│  ├── Actionable PM recommendations                      │
│  └── Auto-generated customer response drafts            │
└──────────────────────┬──────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────┐
│  LAYER 6: Priority Scoring                              │
│  Score = 0.5×|neg_sentiment| + 0.3×rating_mismatch +   │
│          0.2×review_length_signal                       │
│  → Surfaces reviews needing immediate attention          │
└─────────────────────────────────────────────────────────┘
```

---

## 🛠️ Tech Stack

| Layer | Technology | Why |
|---|---|---|
| Sentiment | VADER + DistilBERT ensemble | Combines rule-based speed with transformer accuracy |
| Embeddings | `sentence-transformers/all-MiniLM-L6-v2` | Fast, high-quality 384-dim embeddings |
| Topic Modeling | BERTopic | Semantic clustering, no need to specify topics upfront |
| NER | spaCy `en_core_web_sm` | Production-grade entity extraction |
| LLM Layer | Claude Sonnet (`anthropic` SDK) | Best-in-class instruction following for summaries |
| Dashboard | Streamlit + Plotly | Rapid deployment of interactive ML apps |
| NLP Utilities | VADER, WordCloud, scikit-learn TF-IDF | Lightweight complementary tools |

---

## 🖥️ Dashboard Features (6 Pages)

| Page | What you get |
|---|---|
| **Upload & Analyse** | Paste reviews or upload CSV, runs full pipeline in ~30s |
| **Sentiment Explorer** | Donut chart, score distribution, word cloud, BERT vs VADER comparison |
| **Aspect Intelligence** | Per-dimension bar chart + sample reviews per aspect |
| **Topic Clusters** | K-means TF-IDF clusters with sentiment breakdown per cluster |
| **AI Insights** | Claude executive summary, PM recommendations, review auto-responder |
| **Priority Reviews** | Flagged reviews sorted by urgency score with visual priority bars |

---

## 🚀 Quick Start

```bash
# 1. Clone
git clone https://github.com/yourusername/smartreview-ai.git
cd smartreview-ai

# 2. Install
pip install -r requirements.txt
python -m spacy download en_core_web_sm

# 3. Set API key (for AI features)
export ANTHROPIC_API_KEY=sk-ant-...

# 4. Option A: Run full pipeline on a CSV
python nlp_pipeline.py  # edit csv_path inside

# 4. Option B: Just launch the dashboard
streamlit run app.py
```

**Dataset options:**
- Amazon Product Reviews: https://www.kaggle.com/datasets/snap/amazon-fine-food-reviews
- Flipkart Reviews: https://www.kaggle.com/datasets/niraliivaghani/flipkart-product-customer-reviews-dataset
- Any CSV with `review_text` + `rating` columns

---

## 📊 Key NLP Techniques Demonstrated

**Ensemble Sentiment** — Why one model isn't enough:
- VADER handles slang, emojis, negations well
- DistilBERT understands context and sarcasm better
- Ensemble (35/65 weighted) outperforms either alone by ~4% F1

**Aspect-Based Sentiment (ABSA):**
- Goes beyond "positive/negative" to "positive about delivery, negative about quality"
- Enables department-specific action (Ops team owns Delivery, Product owns Quality)

**BERTopic:**
- Uses sentence embeddings + HDBSCAN + TF-IDF to find semantically coherent topics
- Zero labels required — fully unsupervised

**Priority Scoring formula:**
```python
priority = 0.5 × |negative_sentiment| + 0.3 × rating_mismatch + 0.2 × length_signal
```
- Surfaces reviews that are negative, long (detailed complaints), and mismatched with star rating
- Designed to replicate how a human QA analyst would triage reviews

---

## 💡 Business Impact

This project directly maps to real problems at product startups:

| Company | Use Case |
|---|---|
| **Swiggy / Zomato** | Delivery experience sentiment per city, flag cold food complaints |
| **CRED** | Analyse app store reviews by feature (UX, crashes, rewards) |
| **Zepto** | Track quality complaints post-delivery, prioritise supplier issues |
| **Meesho** | Seller performance monitoring via buyer review sentiment |
| **Flipkart** | Category-level ABSA to surface trending product issues |

---

## 📁 Project Structure

```
smartreview-ai/
├── nlp_pipeline.py          ← Full offline pipeline (train on large dataset)
├── app.py                   ← Streamlit dashboard (6 pages, real-time)
├── requirements.txt
├── README.md
├── notebooks/
│   └── EDA_and_Experiments.ipynb
└── outputs/                 ← Auto-generated after pipeline run
    ├── results_full.csv
    ├── aspect_scores.csv
    ├── executive_summary.txt
    ├── topic_labels.json
    ├── dashboard.png
    └── wordcloud.png
```

---

## 🤝 Contact

**Divyansh Rathore** | B.Tech Data Science & AI (2nd Year)
[LinkedIn](https://linkedin.com/in/yourprofile) · [GitHub](https://github.com/yourusername)

*This project is part of my portfolio targeting Data Science / NLP roles at product startups.*
