"""
SmartReview AI — Streamlit Dashboard
=====================================
A production-grade NLP review intelligence platform.
Run: streamlit run app.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import json
import os
import pickle
import anthropic
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from transformers import pipeline as hf_pipeline
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# ── Config ───────────────────────────────────────────────
st.set_page_config(
    page_title="SmartReview AI",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── CSS ──────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap');
  html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

  .main { background: #0F172A; }

  .sentiment-pill {
    display: inline-block; padding: 4px 14px; border-radius: 20px;
    font-size: 12px; font-weight: 700; letter-spacing: 0.5px;
  }
  .pill-positive { background: rgba(34,197,94,0.15); color: #22C55E; border: 1px solid rgba(34,197,94,0.3); }
  .pill-neutral  { background: rgba(245,158,11,0.15); color: #F59E0B; border: 1px solid rgba(245,158,11,0.3); }
  .pill-negative { background: rgba(239,68,68,0.15);  color: #EF4444; border: 1px solid rgba(239,68,68,0.3); }

  .review-card {
    background: #1E293B; border: 1px solid #334155; border-radius: 12px;
    padding: 16px; margin-bottom: 12px;
  }

  .metric-card {
    background: linear-gradient(135deg, #1e3a5f, #1E293B);
    border: 1px solid #2563EB33; border-radius: 12px;
    padding: 20px; text-align: center;
  }

  .insight-card {
    background: #1E293B; border-left: 3px solid;
    padding: 14px 18px; border-radius: 0 10px 10px 0; margin-bottom: 10px;
  }
</style>
""", unsafe_allow_html=True)

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# ── Sidebar ───────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🧠 SmartReview AI")
    st.caption("NLP-powered review intelligence")
    st.divider()

    page = st.radio("", [
        "🏠 Upload & Analyse",
        "📊 Sentiment Explorer",
        "🎯 Aspect Intelligence",
        "🗂️ Topic Clusters",
        "🤖 AI Insights",
        "🚨 Priority Reviews",
    ], label_visibility="collapsed")

    st.divider()
    api_key_input = st.text_input("Claude API Key", type="password",
                                   value=ANTHROPIC_API_KEY, placeholder="sk-ant-...")
    if api_key_input:
        ANTHROPIC_API_KEY = api_key_input

    st.caption("Built by Divyansh Rathore")
    st.caption("B.Tech Data Science & AI")


# ── Cached models ─────────────────────────────────────────
@st.cache_resource
def get_vader():
    return SentimentIntensityAnalyzer()

@st.cache_resource
def get_bert_pipe():
    return hf_pipeline(
        "sentiment-analysis",
        model="distilbert-base-uncased-finetuned-sst-2-english",
        truncation=True, max_length=512
    )

ASPECT_KEYWORDS = {
    "Delivery":       ["delivery", "shipping", "arrived", "package", "late", "fast"],
    "Quality":        ["quality", "durable", "material", "built", "sturdy", "broke"],
    "Price / Value":  ["price", "cost", "expensive", "cheap", "value", "worth", "money"],
    "Customer Care":  ["support", "service", "return", "refund", "helpdesk", "response"],
    "Packaging":      ["packaging", "box", "wrapped", "damage", "sealed", "torn"],
    "Performance":    ["performance", "speed", "slow", "efficient", "battery", "works"],
    "Design":         ["design", "look", "colour", "color", "size", "weight", "slim"],
}

def analyse_reviews(texts: list[str]) -> pd.DataFrame:
    vader = get_vader()
    bert = get_bert_pipe()

    vader_scores = [vader.polarity_scores(t)["compound"] for t in texts]
    bert_results = bert(texts[:200], batch_size=32, truncation=True)  # cap for speed
    bert_score = [
        r["score"] if r["label"] == "POSITIVE" else -r["score"]
        for r in bert_results
    ]
    # Pad if needed
    bert_score += [0] * (len(texts) - len(bert_score))
    ensemble = [0.35 * v + 0.65 * b for v, b in zip(vader_scores, bert_score)]

    def label(s):
        return "positive" if s > 0.15 else ("negative" if s < -0.15 else "neutral")

    # Aspect scores
    aspect_records = []
    for text in texts:
        tl = text.lower()
        row = {}
        for aspect, kws in ASPECT_KEYWORDS.items():
            sentences = [s for s in tl.split(".") if any(k in s for k in kws)]
            if sentences:
                row[aspect] = round(vader.polarity_scores(" ".join(sentences))["compound"], 3)
            else:
                row[aspect] = None
        aspect_records.append(row)

    aspect_df = pd.DataFrame(aspect_records)

    return pd.DataFrame({
        "sentiment_score": ensemble,
        "sentiment_label": [label(s) for s in ensemble],
        "vader_score": vader_scores,
        "bert_score": bert_score,
    }), aspect_df


# ── Helper: Claude API call ───────────────────────────────
def call_claude(prompt: str, max_tokens: int = 600) -> str:
    if not ANTHROPIC_API_KEY:
        return "⚠️ Add your Claude API key in the sidebar to enable AI features."
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    msg = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=max_tokens,
        messages=[{"role": "user", "content": prompt}]
    )
    return msg.content[0].text.strip()


# ══════════════════════════════════════════════════════════
# PAGE 0: UPLOAD & ANALYSE
# ══════════════════════════════════════════════════════════
if page == "🏠 Upload & Analyse":
    st.title("🧠 SmartReview AI")
    st.markdown("#### Paste reviews or upload a CSV — get instant NLP intelligence.")

    col_left, col_right = st.columns([3, 2])

    with col_left:
        input_method = st.radio("Input method", ["Paste reviews", "Upload CSV"], horizontal=True)

        if input_method == "Paste reviews":
            raw = st.text_area(
                "Paste up to 50 reviews, one per line",
                height=250,
                placeholder="This product is amazing! Delivery was super fast...\nTerrible quality, broke in 2 days. Very disappointed.\nDecent value for money, packaging was nice."
            )
            reviews = [r.strip() for r in raw.strip().split("\n") if len(r.strip()) > 15] if raw else []
            ratings = [3] * len(reviews)

        else:
            uploaded = st.file_uploader("Upload CSV with 'review_text' and 'rating' columns", type="csv")
            if uploaded:
                df_upload = pd.read_csv(uploaded)
                col_map = {}
                for col in df_upload.columns:
                    lc = col.lower()
                    if "review" in lc and ("text" in lc or "body" in lc): col_map[col] = "review_text"
                    elif "rating" in lc or "score" in lc: col_map[col] = "rating"
                df_upload.rename(columns=col_map, inplace=True)
                df_upload = df_upload.dropna(subset=["review_text"]).head(500)
                reviews = df_upload["review_text"].astype(str).tolist()
                ratings = df_upload["rating"].astype(float).tolist() if "rating" in df_upload else [3] * len(reviews)
                st.success(f"Loaded {len(reviews):,} reviews")
            else:
                reviews, ratings = [], []

    with col_right:
        st.markdown("**What SmartReview AI does:**")
        for step in [
            ("🔵", "Ensemble Sentiment", "VADER + DistilBERT"),
            ("🟣", "Aspect Analysis", "7 business dimensions"),
            ("🟡", "Topic Clusters", "BERTopic unsupervised"),
            ("🔴", "Priority Scoring", "Flag urgent reviews"),
            ("🟢", "AI Summary", "Claude executive insight"),
        ]:
            st.markdown(f"{step[0]} **{step[1]}** — {step[2]}")

        product_name = st.text_input("Product name (optional)", placeholder="e.g. OnePlus Nord 4")

    if reviews and st.button("🚀 Analyse Reviews", type="primary", use_container_width=True):
        with st.spinner("Running NLP pipeline... (30–60s for large batches)"):
            sent_df, aspect_df = analyse_reviews(reviews)

            full_df = pd.DataFrame({"review_text": reviews, "rating": ratings})
            full_df = pd.concat([full_df.reset_index(drop=True), sent_df], axis=1)

            # Priority score
            full_df["rating_norm"] = (full_df["rating"] - 1) / 4
            full_df["mismatch"] = abs(
                full_df["rating_norm"] - (full_df["sentiment_score"].clip(-1, 1) + 1) / 2
            )
            full_df["priority_score"] = (
                (-full_df["sentiment_score"]).clip(0) * 0.5 +
                full_df["mismatch"] * 0.3 +
                (full_df["review_text"].str.len() / 1000).clip(0, 1) * 0.2
            ).round(3)

            st.session_state["df"] = full_df
            st.session_state["aspect_df"] = aspect_df
            st.session_state["product_name"] = product_name or "Product"

        st.success(f"✅ Analysed {len(reviews)} reviews! Navigate the pages in the sidebar.")

        # Quick summary
        c1, c2, c3, c4 = st.columns(4)
        pct_pos = (full_df["sentiment_label"] == "positive").mean() * 100
        pct_neg = (full_df["sentiment_label"] == "negative").mean() * 100
        avg_score = full_df["sentiment_score"].mean()
        c1.metric("Total Reviews", f"{len(reviews):,}")
        c2.metric("Positive", f"{pct_pos:.0f}%", delta=f"+{pct_pos:.0f}%")
        c3.metric("Negative", f"{pct_neg:.0f}%", delta=f"-{pct_neg:.0f}%", delta_color="inverse")
        c4.metric("Avg Sentiment", f"{avg_score:+.2f}", delta="BERT+VADER")
    else:
        if not reviews:
            st.info("👆 Paste some reviews above and click Analyse.")


def check_data():
    if "df" not in st.session_state:
        st.warning("No data yet — go to **🏠 Upload & Analyse** and analyse some reviews first.")
        st.stop()
    return st.session_state["df"], st.session_state["aspect_df"], st.session_state.get("product_name", "Product")


# ══════════════════════════════════════════════════════════
# PAGE 1: SENTIMENT EXPLORER
# ══════════════════════════════════════════════════════════
elif page == "📊 Sentiment Explorer":
    df, aspect_df, product_name = check_data()
    st.title("📊 Sentiment Explorer")

    c1, c2, c3 = st.columns(3)
    for col, label, filt, color in [
        (c1, "Positive", "positive", "#22C55E"),
        (c2, "Neutral",  "neutral",  "#F59E0B"),
        (c3, "Negative", "negative", "#EF4444"),
    ]:
        n = (df["sentiment_label"] == filt).sum()
        col.markdown(f"""
        <div style="background:#1E293B;border:1px solid {color}33;border-radius:12px;padding:20px;text-align:center">
          <div style="font-size:32px;font-weight:900;color:{color}">{n}</div>
          <div style="color:#64748B;font-size:13px">{label} Reviews</div>
          <div style="color:{color};font-size:13px">{n/len(df)*100:.1f}%</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("---")

    col_a, col_b = st.columns(2)

    with col_a:
        # Sentiment distribution donut
        counts = df["sentiment_label"].value_counts()
        fig = go.Figure(go.Pie(
            labels=counts.index, values=counts.values,
            hole=0.55,
            marker=dict(colors=["#22C55E", "#F59E0B", "#EF4444"]),
        ))
        fig.update_layout(
            title="Sentiment Split", paper_bgcolor="#0F172A",
            font=dict(color="#E2E8F0"), showlegend=True, height=300, margin=dict(t=40, b=10)
        )
        st.plotly_chart(fig, use_container_width=True)

    with col_b:
        # Rating vs Sentiment scatter
        fig2 = px.scatter(df, x="rating", y="sentiment_score",
            color="sentiment_label",
            color_discrete_map={"positive": "#22C55E", "neutral": "#F59E0B", "negative": "#EF4444"},
            opacity=0.6, title="Star Rating vs AI Sentiment Score"
        )
        fig2.update_layout(paper_bgcolor="#0F172A", plot_bgcolor="#1E293B", font=dict(color="#E2E8F0"), height=300)
        st.plotly_chart(fig2, use_container_width=True)

    # Sentiment distribution of scores
    fig3 = px.histogram(df, x="sentiment_score", color="sentiment_label", nbins=40,
        color_discrete_map={"positive": "#22C55E", "neutral": "#F59E0B", "negative": "#EF4444"},
        title="Distribution of Sentiment Scores",
        barmode="overlay"
    )
    fig3.add_vline(x=0, line_dash="dash", line_color="#64748B")
    fig3.update_layout(paper_bgcolor="#0F172A", plot_bgcolor="#1E293B", font=dict(color="#E2E8F0"), height=280)
    st.plotly_chart(fig3, use_container_width=True)

    # Word cloud
    st.subheader("Review Word Cloud")
    all_text = " ".join(df["review_text"].values)
    try:
        wc = WordCloud(width=900, height=280, background_color="#1E293B",
                       colormap="Blues", max_words=120).generate(all_text)
        fig_wc, ax = plt.subplots(figsize=(12, 3.5), facecolor="#1E293B")
        ax.imshow(wc, interpolation="bilinear"); ax.axis("off")
        st.pyplot(fig_wc)
    except Exception:
        st.info("WordCloud requires more text data.")


# ══════════════════════════════════════════════════════════
# PAGE 2: ASPECT INTELLIGENCE
# ══════════════════════════════════════════════════════════
elif page == "🎯 Aspect Intelligence":
    df, aspect_df, product_name = check_data()
    st.title("🎯 Aspect-Based Sentiment Analysis")
    st.caption("How do customers feel about each dimension of the product?")

    means = aspect_df.mean().dropna().sort_values()
    colors = ["#EF4444" if v < -0.1 else "#22C55E" if v > 0.1 else "#F59E0B" for v in means.values]

    fig = go.Figure(go.Bar(
        x=means.values, y=means.index, orientation="h",
        marker=dict(color=colors),
        text=[f"{v:+.2f}" for v in means.values], textposition="outside"
    ))
    fig.add_vline(x=0, line_color="#64748B", line_dash="dash")
    fig.update_layout(
        title="Aspect Sentiment Scores (−1 → +1)",
        paper_bgcolor="#0F172A", plot_bgcolor="#1E293B",
        font=dict(color="#E2E8F0"), height=350,
        xaxis=dict(range=[-1.1, 1.1])
    )
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Aspect Score Breakdown")
    cols = st.columns(len(ASPECT_KEYWORDS))
    for i, (aspect, _) in enumerate(ASPECT_KEYWORDS.items()):
        if aspect in aspect_df.columns:
            val = aspect_df[aspect].mean()
            if not np.isnan(val):
                color = "#EF4444" if val < -0.1 else "#22C55E" if val > 0.1 else "#F59E0B"
                emoji = "🔴" if val < -0.1 else "🟢" if val > 0.1 else "🟡"
                cols[i].markdown(f"""
                <div style="background:#1E293B;border:1px solid {color}33;border-radius:10px;padding:14px;text-align:center">
                  <div style="font-size:20px">{emoji}</div>
                  <div style="font-weight:700;font-size:13px;margin:6px 0;color:#E2E8F0">{aspect}</div>
                  <div style="font-size:18px;font-weight:900;color:{color}">{val:+.2f}</div>
                </div>""", unsafe_allow_html=True)

    st.subheader("Sample Reviews by Aspect")
    selected_aspect = st.selectbox("Pick an aspect", list(ASPECT_KEYWORDS.keys()))
    kws = ASPECT_KEYWORDS[selected_aspect]
    filtered = df[df["review_text"].str.lower().str.contains("|".join(kws), na=False)]
    if not filtered.empty:
        for _, row in filtered.head(5).iterrows():
            pill_cls = f"pill-{row['sentiment_label']}"
            st.markdown(f"""
            <div class="review-card">
              <span class="sentiment-pill {pill_cls}">{row['sentiment_label'].upper()}</span>
              <span style="color:#64748B;font-size:12px;margin-left:10px">Score: {row['sentiment_score']:+.2f}</span>
              <p style="color:#CBD5E1;margin-top:10px;margin-bottom:0;font-size:14px">{row['review_text'][:300]}</p>
            </div>""", unsafe_allow_html=True)
    else:
        st.info("No reviews found for this aspect.")


# ══════════════════════════════════════════════════════════
# PAGE 3: TOPIC CLUSTERS
# ══════════════════════════════════════════════════════════
elif page == "🗂️ Topic Clusters":
    df, aspect_df, product_name = check_data()
    st.title("🗂️ Topic Clusters")
    st.caption("What themes are customers actually talking about? (Uses keyword TF-IDF clusters)")

    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.cluster import KMeans

    texts = df["review_text"].astype(str).tolist()
    n_clusters = st.slider("Number of topic clusters", 3, 10, 6)

    with st.spinner("Clustering reviews..."):
        vectorizer = TfidfVectorizer(max_features=500, stop_words="english", ngram_range=(1, 2))
        X = vectorizer.fit_transform(texts)
        km = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        clusters = km.fit_predict(X)
        df["cluster"] = clusters

        terms = vectorizer.get_feature_names_out()
        cluster_labels = {}
        for c in range(n_clusters):
            center = km.cluster_centers_[c]
            top_terms = [terms[i] for i in center.argsort()[-5:][::-1]]
            cluster_labels[c] = " · ".join(top_terms)

    for c in range(n_clusters):
        cluster_df = df[df["cluster"] == c]
        pct_pos = (cluster_df["sentiment_label"] == "positive").mean()
        color = "#22C55E" if pct_pos > 0.6 else "#EF4444" if pct_pos < 0.35 else "#F59E0B"
        with st.expander(f"**Cluster {c+1}:** {cluster_labels[c]} ({len(cluster_df)} reviews)", expanded=(c == 0)):
            cc1, cc2 = st.columns([1, 3])
            with cc1:
                st.markdown(f"<div style='font-size:28px;font-weight:900;color:{color}'>{pct_pos*100:.0f}%</div><div style='color:#64748B;font-size:12px'>Positive</div>", unsafe_allow_html=True)
                st.markdown(f"<div style='color:#64748B;font-size:12px'>{len(cluster_df)} reviews</div>")
            with cc2:
                for _, row in cluster_df.head(3).iterrows():
                    pill = f"pill-{row['sentiment_label']}"
                    st.markdown(f"""<div style="background:#0F172A;border-radius:8px;padding:10px;margin-bottom:8px">
                    <span class="sentiment-pill {pill}">{row['sentiment_label']}</span>
                    <span style="color:#94A3B8;font-size:13px;margin-left:8px">{row['review_text'][:200]}</span></div>""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════
# PAGE 4: AI INSIGHTS
# ══════════════════════════════════════════════════════════
elif page == "🤖 AI Insights":
    df, aspect_df, product_name = check_data()
    st.title("🤖 AI-Powered Insights")
    st.caption("Claude generates executive summaries and actionable recommendations.")

    tab1, tab2, tab3 = st.tabs(["📋 Executive Summary", "💡 Actionable Recs", "💬 Review Responder"])

    with tab1:
        if st.button("Generate Executive Summary", type="primary"):
            with st.spinner("Claude is analysing your reviews..."):
                sentiment_dist = df["sentiment_label"].value_counts().to_dict()
                aspect_means = {k: round(float(v), 3) for k, v in aspect_df.mean().items() if not np.isnan(v)}
                neg_samples = df[df["sentiment_label"] == "negative"]["review_text"].head(3).tolist()
                pos_samples = df[df["sentiment_label"] == "positive"]["review_text"].head(2).tolist()

                prompt = f"""You are a senior product analyst at a top Indian startup (like Swiggy or CRED).
Analyse these review metrics for "{product_name}" and write a crisp executive summary.

SENTIMENT: {json.dumps(sentiment_dist)}
ASPECT SCORES (−1=worst, +1=best): {json.dumps(aspect_means)}
NEGATIVE REVIEWS: {chr(10).join(neg_samples)}
POSITIVE REVIEWS: {chr(10).join(pos_samples)}

Write a 3-section report:
1. **Overall Verdict** (2-3 lines, data-driven)
2. **Top 3 Strengths** (with evidence from reviews)
3. **Top 3 Urgent Issues** (actionable for product/ops team, prioritised)

Be sharp, startup-style. No fluff."""

                summary = call_claude(prompt, max_tokens=700)
                st.markdown(summary)

    with tab2:
        if st.button("Generate Recommendations", type="primary"):
            with st.spinner("Generating recommendations..."):
                aspect_means = {k: round(float(v), 3) for k, v in aspect_df.mean().items() if not np.isnan(v)}
                prompt = f"""As a Growth PM at a product startup, convert these NLP insights into a prioritised action plan.

Product: {product_name}
Aspect scores: {json.dumps(aspect_means)}
% Negative: {(df['sentiment_label']=='negative').mean()*100:.1f}%

Give me exactly 5 actionable recommendations, each with:
- Priority: HIGH/MEDIUM/LOW
- Department: which team owns it (Product/Ops/Support/Marketing)
- Action: what to do (specific, not vague)
- Expected Impact: why this matters

Format as a clean numbered list."""

                recs = call_claude(prompt, max_tokens=600)
                st.markdown(recs)

    with tab3:
        st.markdown("**Auto-generate professional responses to customer reviews**")
        review_input = st.text_area("Paste a customer review:", height=100,
            placeholder="The product stopped working after 3 days. Very disappointed with the quality.")
        if review_input and st.button("Generate Response"):
            with st.spinner("Writing response..."):
                vader = get_vader()
                score = vader.polarity_scores(review_input)["compound"]
                sentiment = "positive" if score > 0.1 else "negative" if score < -0.1 else "neutral"
                prompt = f"""You are a customer success manager at {product_name or 'our company'}.
Write a professional, empathetic, specific response to this {sentiment} review in 2-3 sentences.
Never be generic. Acknowledge the specific issue. For negative: apologise + offer resolution. For positive: thank + personalise.

Review: "{review_input}"

Response (just the response text, no preamble):"""
                response = call_claude(prompt, max_tokens=200)
                color = "#22C55E" if sentiment == "positive" else "#EF4444" if sentiment == "negative" else "#F59E0B"
                st.markdown(f"""<div style="background:#1E293B;border-left:3px solid {color};border-radius:0 10px 10px 0;padding:16px;margin-top:12px">
                <div style="color:#64748B;font-size:12px;margin-bottom:8px">SUGGESTED RESPONSE · Detected: <span style="color:{color};font-weight:700">{sentiment.upper()}</span></div>
                <div style="color:#E2E8F0;font-size:14px;line-height:1.7">{response}</div></div>""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════
# PAGE 5: PRIORITY REVIEWS
# ══════════════════════════════════════════════════════════
elif page == "🚨 Priority Reviews":
    df, aspect_df, product_name = check_data()
    st.title("🚨 Priority Reviews Dashboard")
    st.caption("Reviews that need immediate attention — negative, detailed, or mismatched with star ratings.")

    priority_df = df.sort_values("priority_score", ascending=False)

    c1, c2, c3 = st.columns(3)
    c1.metric("High Priority Reviews", (df["priority_score"] > 0.4).sum())
    c2.metric("Rating-Sentiment Mismatch", (df["mismatch"] > 0.5).sum())
    c3.metric("Avg Priority Score", f"{df['priority_score'].mean():.3f}")

    threshold = st.slider("Priority threshold", 0.0, 1.0, 0.3, 0.05)
    flagged = priority_df[priority_df["priority_score"] >= threshold]
    st.markdown(f"**{len(flagged)} reviews above threshold**")

    for _, row in flagged.head(15).iterrows():
        pill_cls = f"pill-{row['sentiment_label']}"
        bar_width = int(row["priority_score"] * 100)
        st.markdown(f"""
        <div class="review-card">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <div>
              <span class="sentiment-pill {pill_cls}">{row['sentiment_label'].upper()}</span>
              <span style="color:#64748B;font-size:12px;margin-left:8px">⭐ {row['rating']:.0f}/5 · Sentiment: {row['sentiment_score']:+.2f}</span>
            </div>
            <div style="text-align:right">
              <span style="color:#F59E0B;font-weight:700;font-size:13px">Priority: {row['priority_score']:.3f}</span>
              <div style="width:80px;height:4px;background:#334155;border-radius:2px;margin-top:4px">
                <div style="width:{bar_width}%;height:100%;background:#F59E0B;border-radius:2px"></div>
              </div>
            </div>
          </div>
          <p style="color:#CBD5E1;margin:0;font-size:14px;line-height:1.6">{row['review_text'][:400]}</p>
        </div>""", unsafe_allow_html=True)
