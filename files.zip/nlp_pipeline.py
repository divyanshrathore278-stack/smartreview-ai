"""
SmartReview AI — NLP Pipeline
==============================
Multilayer NLP pipeline:
  Layer 1: Sentiment Analysis (VADER + DistilBERT ensemble)
  Layer 2: Aspect-Based Sentiment (ABSA) with spaCy
  Layer 3: Topic Modeling with BERTopic
  Layer 4: Named Entity Recognition (product, brand, feature)
  Layer 5: LLM Executive Summary via Claude/OpenAI API
  Layer 6: Insight scoring & prioritization

Author: Divyansh Rathore
Dataset: Amazon Product Reviews (Kaggle) or any CSV with 'review_text' + 'rating'
"""

import pandas as pd
import numpy as np
import re
import json
import os
import pickle
import warnings
from collections import defaultdict, Counter
from typing import Optional

warnings.filterwarnings("ignore")

# ── NLP Libraries ────────────────────────────────────────
import spacy
from spacy import displacy

from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

from transformers import pipeline as hf_pipeline, AutoTokenizer, AutoModelForSequenceClassification
from sentence_transformers import SentenceTransformer

from bertopic import BERTopic
from sklearn.feature_extraction.text import CountVectorizer

import matplotlib.pyplot as plt
import matplotlib.cm as cm
import seaborn as sns
from wordcloud import WordCloud

# ── LLM Client ──────────────────────────────────────────
import anthropic  # pip install anthropic

os.makedirs("outputs", exist_ok=True)
os.makedirs("models", exist_ok=True)


# ════════════════════════════════════════════════════════
# LAYER 0: DATA LOADING & CLEANING
# ════════════════════════════════════════════════════════

def load_and_clean(path: str, sample_n: int = 2000) -> pd.DataFrame:
    """Load Amazon reviews CSV, clean text, sample for speed."""
    print("📥 Loading data...")
    df = pd.read_csv(path)

    # Standardise column names (handles different Kaggle formats)
    col_map = {}
    for col in df.columns:
        lc = col.lower().strip()
        if "review" in lc and "text" in lc:   col_map[col] = "review_text"
        elif "rating" in lc or "score" in lc:  col_map[col] = "rating"
        elif "summary" in lc or "title" in lc: col_map[col] = "review_title"
        elif "product" in lc or "asin" in lc:  col_map[col] = "product_id"
    df.rename(columns=col_map, inplace=True)

    required = ["review_text", "rating"]
    for col in required:
        if col not in df.columns:
            raise ValueError(f"Column '{col}' not found. Available: {df.columns.tolist()}")

    df = df[required + [c for c in ["review_title", "product_id"] if c in df.columns]].copy()
    df.dropna(subset=["review_text", "rating"], inplace=True)
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
    df.dropna(subset=["rating"], inplace=True)
    df["rating"] = df["rating"].astype(int).clip(1, 5)
    df["review_text"] = df["review_text"].astype(str).str.strip()
    df = df[df["review_text"].str.len() > 30]  # remove stub reviews

    # Clean text
    def clean(text):
        text = re.sub(r"<[^>]+>", " ", text)      # HTML
        text = re.sub(r"http\S+", "", text)         # URLs
        text = re.sub(r"[^\w\s\.\!\?\,\'\-]", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    df["clean_text"] = df["review_text"].apply(clean)
    df = df.sample(min(sample_n, len(df)), random_state=42).reset_index(drop=True)
    print(f"✅ Loaded {len(df):,} reviews | Rating dist: {df['rating'].value_counts().sort_index().to_dict()}")
    return df


# ════════════════════════════════════════════════════════
# LAYER 1: SENTIMENT ANALYSIS (ENSEMBLE)
# ════════════════════════════════════════════════════════

class SentimentAnalyser:
    """Ensemble: VADER (lexicon) + DistilBERT (transformer)"""

    def __init__(self):
        print("🔄 Loading sentiment models...")
        self.vader = SentimentIntensityAnalyzer()
        self.bert_pipe = hf_pipeline(
            "sentiment-analysis",
            model="distilbert-base-uncased-finetuned-sst-2-english",
            truncation=True, max_length=512
        )

    def analyse_batch(self, texts: list[str]) -> pd.DataFrame:
        # VADER scores
        vader_scores = [self.vader.polarity_scores(t) for t in texts]
        vader_compound = [s["compound"] for s in vader_scores]

        # DistilBERT scores (batch)
        bert_results = self.bert_pipe(texts, batch_size=32)
        bert_score = [
            r["score"] if r["label"] == "POSITIVE" else -r["score"]
            for r in bert_results
        ]

        # Ensemble (BERT-weighted)
        ensemble = [0.35 * v + 0.65 * b for v, b in zip(vader_compound, bert_score)]

        def label(score):
            if score > 0.15:  return "positive"
            if score < -0.15: return "negative"
            return "neutral"

        return pd.DataFrame({
            "vader_compound": vader_compound,
            "bert_score": bert_score,
            "sentiment_score": ensemble,
            "sentiment_label": [label(s) for s in ensemble],
        })


# ════════════════════════════════════════════════════════
# LAYER 2: ASPECT-BASED SENTIMENT (ABSA)
# ════════════════════════════════════════════════════════

ASPECT_KEYWORDS = {
    "delivery":      ["delivery", "shipping", "arrived", "package", "courier", "dispatch", "late", "fast"],
    "quality":       ["quality", "durable", "material", "built", "sturdy", "flimsy", "broke", "excellent"],
    "price":         ["price", "cost", "expensive", "cheap", "value", "worth", "money", "overpriced", "affordable"],
    "customer_care": ["support", "service", "return", "refund", "helpdesk", "response", "resolved", "rude"],
    "packaging":     ["packaging", "box", "wrapped", "damage", "sealed", "unboxing", "torn"],
    "performance":   ["performance", "speed", "slow", "fast", "efficient", "powerful", "battery", "works"],
    "design":        ["design", "look", "colour", "color", "size", "weight", "aesthetic", "slim", "ugly"],
}

class ABSAnalyser:
    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")
        self.vader = SentimentIntensityAnalyzer()

    def extract_aspects(self, text: str) -> dict:
        text_lower = text.lower()
        results = {}
        for aspect, keywords in ASPECT_KEYWORDS.items():
            sentences = [s for s in text_lower.split(".") if any(k in s for k in keywords)]
            if sentences:
                combined = " ".join(sentences)
                score = self.vader.polarity_scores(combined)["compound"]
                results[aspect] = round(score, 3)
        return results

    def analyse_batch(self, texts: list[str]) -> pd.DataFrame:
        records = [self.extract_aspects(t) for t in texts]
        df = pd.DataFrame(records)
        df.fillna(0, inplace=True)
        return df


# ════════════════════════════════════════════════════════
# LAYER 3: TOPIC MODELING (BERTopic)
# ════════════════════════════════════════════════════════

class TopicModeller:
    def __init__(self, n_topics: int = 8):
        print("🔄 Initialising BERTopic...")
        self.embedder = SentenceTransformer("all-MiniLM-L6-v2")
        vectorizer = CountVectorizer(
            stop_words="english", ngram_range=(1, 2), min_df=3
        )
        self.model = BERTopic(
            embedding_model=self.embedder,
            vectorizer_model=vectorizer,
            nr_topics=n_topics,
            verbose=False
        )

    def fit_transform(self, texts: list[str]):
        print("🔄 Fitting BERTopic...")
        topics, probs = self.model.fit_transform(texts)
        topic_info = self.model.get_topic_info()
        print(f"✅ Found {len(topic_info) - 1} topics")
        return topics, probs, topic_info

    def get_topic_labels(self) -> dict:
        """Return {topic_id: top_words_string}"""
        labels = {}
        for topic_id in self.model.get_topics():
            if topic_id == -1: continue
            words = [w for w, _ in self.model.get_topic(topic_id)[:5]]
            labels[topic_id] = " · ".join(words)
        return labels


# ════════════════════════════════════════════════════════
# LAYER 4: NAMED ENTITY EXTRACTION
# ════════════════════════════════════════════════════════

class EntityExtractor:
    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")

    def extract(self, texts: list[str], top_n: int = 20) -> dict:
        brands, products, orgs = Counter(), Counter(), Counter()
        for text in texts[:500]:  # sample for speed
            doc = self.nlp(text[:512])
            for ent in doc.ents:
                if ent.label_ in ("ORG", "PRODUCT"):
                    (brands if ent.label_ == "ORG" else products)[ent.text.strip()] += 1
        return {
            "top_brands": brands.most_common(top_n),
            "top_products": products.most_common(top_n),
        }


# ════════════════════════════════════════════════════════
# LAYER 5: LLM EXECUTIVE SUMMARY (Claude API)
# ════════════════════════════════════════════════════════

class LLMSummariser:
    def __init__(self, api_key: Optional[str] = None):
        self.client = anthropic.Anthropic(api_key=api_key or os.environ["ANTHROPIC_API_KEY"])

    def generate_executive_summary(
        self,
        sentiment_dist: dict,
        top_aspects: dict,
        top_topics: list[str],
        sample_reviews: list[str],
        product_name: str = "the product"
    ) -> str:
        prompt = f"""You are a senior product analyst. Based on the NLP analysis of {len(sample_reviews)} customer reviews for "{product_name}", generate a concise executive summary.

SENTIMENT BREAKDOWN:
{json.dumps(sentiment_dist, indent=2)}

ASPECT SENTIMENT SCORES (−1 worst → +1 best):
{json.dumps(top_aspects, indent=2)}

TOP DISCUSSION TOPICS:
{chr(10).join(f"- {t}" for t in top_topics)}

SAMPLE REVIEWS (5 random):
{chr(10).join(f'{i+1}. "{r[:200]}"' for i, r in enumerate(sample_reviews[:5]))}

Write a 3-section executive summary:
1. **Overall Verdict** (2-3 sentences with sentiment score context)
2. **Top 3 Strengths** (what customers love, with specific evidence)
3. **Top 3 Critical Issues** (what needs fixing, actionable for product team)

Keep it sharp, data-driven, and product-team-ready. No fluff."""

        message = self.client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=600,
            messages=[{"role": "user", "content": prompt}]
        )
        return message.content[0].text

    def generate_review_response(self, review: str, sentiment: str) -> str:
        """Generate a professional response to a customer review."""
        prompt = f"""You are a customer success manager. Write a professional, empathetic response to this {sentiment} customer review in 2-3 sentences. Be specific, not generic.

Review: "{review}"

Response:"""
        message = self.client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=150,
            messages=[{"role": "user", "content": prompt}]
        )
        return message.content[0].text.strip()


# ════════════════════════════════════════════════════════
# LAYER 6: INSIGHT SCORING & EXPORT
# ════════════════════════════════════════════════════════

def compute_insight_score(df: pd.DataFrame) -> pd.DataFrame:
    """Score each review by business impact: negative high-rating anomalies flagged."""
    df = df.copy()
    # Mismatch score: high rating + negative sentiment = data quality issue / sarcasm
    df["rating_norm"] = (df["rating"] - 1) / 4  # 0–1
    df["mismatch"] = abs(df["rating_norm"] - (df["sentiment_score"].clip(-1, 1) + 1) / 2)
    # Business priority: negative sentiment with many aspect hits
    df["priority_score"] = (
        (-df["sentiment_score"]).clip(0) * 0.5 +
        df["mismatch"] * 0.3 +
        (df["clean_text"].str.len() / 1000).clip(0, 1) * 0.2
    ).round(3)
    return df.sort_values("priority_score", ascending=False)


def generate_visualisations(df: pd.DataFrame, aspect_df: pd.DataFrame, topic_labels: dict):
    """Generate and save all charts."""
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    fig.patch.set_facecolor("#0F172A")
    for ax in axes.flat:
        ax.set_facecolor("#1E293B")
        ax.tick_params(colors="#94A3B8")
        ax.spines[:].set_color("#334155")

    # 1. Sentiment distribution
    counts = df["sentiment_label"].value_counts()
    colors = {"positive": "#22C55E", "neutral": "#F59E0B", "negative": "#EF4444"}
    axes[0, 0].bar(counts.index, counts.values, color=[colors.get(l, "#64748B") for l in counts.index])
    axes[0, 0].set_title("Sentiment Distribution", color="white")

    # 2. Rating vs Sentiment
    axes[0, 1].scatter(df["rating"], df["sentiment_score"], alpha=0.3, c="#2563EB", s=10)
    axes[0, 1].set_xlabel("Star Rating", color="#94A3B8")
    axes[0, 1].set_ylabel("Sentiment Score", color="#94A3B8")
    axes[0, 1].set_title("Rating vs Sentiment", color="white")

    # 3. Aspect scores
    aspect_means = aspect_df.mean().sort_values()
    bar_colors = ["#EF4444" if v < 0 else "#22C55E" for v in aspect_means.values]
    axes[0, 2].barh(aspect_means.index, aspect_means.values, color=bar_colors)
    axes[0, 2].axvline(0, color="#64748B", linewidth=1)
    axes[0, 2].set_title("Aspect Sentiment Scores", color="white")

    # 4. Sentiment over review index (trend proxy)
    df["rolling_sent"] = df["sentiment_score"].rolling(50).mean()
    axes[1, 0].plot(df.index, df["rolling_sent"], color="#2563EB", linewidth=1.5)
    axes[1, 0].axhline(0, color="#64748B", linestyle="--", linewidth=1)
    axes[1, 0].set_title("Sentiment Trend (rolling avg)", color="white")

    # 5. Topic distribution
    if topic_labels:
        topic_ids = list(topic_labels.keys())[:7]
        topic_words = [topic_labels[t][:30] for t in topic_ids]
        topic_counts = [len(df[df.get("topic", pd.Series()) == t]) for t in topic_ids]
        axes[1, 1].barh(topic_words, topic_counts, color="#7C3AED")
        axes[1, 1].set_title("Top Review Topics", color="white")

    # 6. Priority review distribution
    axes[1, 2].hist(df["priority_score"], bins=30, color="#F59E0B", edgecolor="#0F172A")
    axes[1, 2].set_title("Business Priority Score Dist.", color="white")
    axes[1, 2].set_xlabel("Priority Score (higher = needs attention)", color="#94A3B8")

    plt.suptitle("SmartReview AI — Analytics Dashboard", color="white", fontsize=16, y=1.01)
    plt.tight_layout()
    plt.savefig("outputs/dashboard.png", dpi=150, bbox_inches="tight", facecolor="#0F172A")
    plt.close()
    print("→ Saved: outputs/dashboard.png")

    # Word cloud
    all_text = " ".join(df["clean_text"].values)
    wc = WordCloud(
        width=1200, height=400, background_color="#0F172A",
        colormap="Blues", max_words=150,
        stopwords={"the", "and", "is", "it", "this", "that", "a", "i", "to", "of", "for", "in"}
    ).generate(all_text)
    plt.figure(figsize=(14, 4), facecolor="#0F172A")
    plt.imshow(wc, interpolation="bilinear")
    plt.axis("off")
    plt.tight_layout()
    plt.savefig("outputs/wordcloud.png", dpi=150, bbox_inches="tight", facecolor="#0F172A")
    plt.close()
    print("→ Saved: outputs/wordcloud.png")


# ════════════════════════════════════════════════════════
# MAIN PIPELINE RUNNER
# ════════════════════════════════════════════════════════

def run_pipeline(csv_path: str, product_name: str = "Product", api_key: str = None):
    print("\n" + "=" * 65)
    print("  SmartReview AI — NLP Intelligence Pipeline")
    print("=" * 65 + "\n")

    # Layer 0: Load
    df = load_and_clean(csv_path)

    # Layer 1: Sentiment
    print("\n[Layer 1] Running ensemble sentiment analysis...")
    sentiment_analyser = SentimentAnalyser()
    sent_df = sentiment_analyser.analyse_batch(df["clean_text"].tolist())
    df = pd.concat([df.reset_index(drop=True), sent_df], axis=1)

    # Layer 2: ABSA
    print("\n[Layer 2] Running aspect-based sentiment analysis...")
    absa = ABSAnalyser()
    aspect_df = absa.analyse_batch(df["clean_text"].tolist())
    aspect_df.index = df.index

    # Layer 3: Topics
    print("\n[Layer 3] Running BERTopic topic modeling...")
    topic_modeller = TopicModeller(n_topics=8)
    topics, probs, topic_info = topic_modeller.fit_transform(df["clean_text"].tolist())
    df["topic"] = topics
    topic_labels = topic_modeller.get_topic_labels()

    # Layer 4: NER
    print("\n[Layer 4] Extracting named entities...")
    ner = EntityExtractor()
    entities = ner.extract(df["clean_text"].tolist())

    # Layer 5: LLM Summary
    print("\n[Layer 5] Generating LLM executive summary...")
    sentiment_dist = df["sentiment_label"].value_counts().to_dict()
    aspect_means = {k: round(float(v), 3) for k, v in aspect_df.mean().items() if v != 0}
    top_topic_words = list(topic_labels.values())[:6]
    sample_reviews = df[df["sentiment_label"] == "negative"]["clean_text"].head(3).tolist() + \
                     df[df["sentiment_label"] == "positive"]["clean_text"].head(2).tolist()

    summariser = LLMSummariser(api_key=api_key)
    exec_summary = summariser.generate_executive_summary(
        sentiment_dist, aspect_means, top_topic_words, sample_reviews, product_name
    )
    print("\n📋 EXECUTIVE SUMMARY:")
    print("─" * 60)
    print(exec_summary)

    # Layer 6: Scoring
    print("\n[Layer 6] Computing insight priority scores...")
    df = compute_insight_score(df)

    # Visualisations
    print("\n[Viz] Generating charts...")
    generate_visualisations(df, aspect_df, topic_labels)

    # Save results
    df.to_csv("outputs/results_full.csv", index=False)
    aspect_df.to_csv("outputs/aspect_scores.csv", index=False)
    with open("outputs/executive_summary.txt", "w") as f:
        f.write(exec_summary)
    with open("outputs/topic_labels.json", "w") as f:
        json.dump(topic_labels, f, indent=2)
    with open("outputs/entities.json", "w") as f:
        json.dump(entities, f, indent=2)

    print("\n✅ Pipeline complete. All outputs saved to /outputs/")
    print("   Run: streamlit run app.py")

    return df, aspect_df, topic_labels, exec_summary


if __name__ == "__main__":
    # Update path to your CSV
    run_pipeline(
        csv_path="reviews.csv",
        product_name="Amazon Electronics",
        api_key=None  # reads from ANTHROPIC_API_KEY env var
    )
